package co.com.pandistore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
