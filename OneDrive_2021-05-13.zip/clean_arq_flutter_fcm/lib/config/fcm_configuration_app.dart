// cd android && ./gradlew signingReport (Genera el SHA1)
// SHA1: 17:B3:EE:A3:31:5D:C1:AE:16:5F:A8:65:3B:DD:71:DD:08:63:46:AA
// Package Name Firebase: co.com.pandistore
// AppName Firebase: PandiStore

import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class PushNotificationsService{

  static FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
  static String? tokenFirebase;

  static Future initializeApp() async{

    // Firebase Initialize App
    await Firebase.initializeApp();

    // Get Token
    tokenFirebase = await firebaseMessaging.getToken();
    print("Firebase Token: $tokenFirebase");

    // Listeners
    FirebaseMessaging.onMessageOpenedApp.listen(onTerminatedHandler);
    FirebaseMessaging.onBackgroundMessage(onBackgroundHandler);
    FirebaseMessaging.onMessage.listen(onForegroundHandler);
  }

  // Handlers
  static Future onForegroundHandler(RemoteMessage message) async{
    print("onForegroundHandler: ${message.messageId} ${message.notification!.title}");
    messageController.add(message.notification!.title!);
  }

  static Future onBackgroundHandler(RemoteMessage message) async{
    print("onBackgroundHandler: ${message.messageId} ${message.notification!.title}");
    messageController.add(message.notification!.title!);
  }

  static Future onTerminatedHandler(RemoteMessage message) async{
    print("onTerminatedHandler: ${message.messageId} ${message.notification!.title}");
    messageController.add(message.notification!.title!);
  }

  // Streams
  static StreamController<String> messageController = new StreamController.broadcast();
  static Stream<String> get message => messageController.stream;

  closeStream(){
    messageController.close();
  }
}
