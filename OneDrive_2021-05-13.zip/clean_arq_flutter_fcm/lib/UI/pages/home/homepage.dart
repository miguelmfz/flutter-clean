
import 'package:clean_arq_flutter/UI/pages/home/components/appbar_home.dart';
import 'package:clean_arq_flutter/UI/pages/home/components/body_home.dart';
import 'package:clean_arq_flutter/config/fcm_configuration_app.dart';
import 'package:clean_arq_flutter/config/usecase_config.dart';
import 'package:clean_arq_flutter/infrastructure/mapper/bloc/counter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';


class HomePage extends StatelessWidget {
  GlobalKey scaffoldKey = new GlobalKey();
  @override
  Widget build(BuildContext context) {
    UseCaseConfig _useCaseConfig = UseCaseConfig();
    PushNotificationsService.messageController.stream.listen((message) {
      final snackBar = SnackBar(
        content: Text(message,
          style: GoogleFonts.nunito(fontSize: 18,
            fontWeight: FontWeight.w500),),
        duration: Duration(seconds: 5),);
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    });
    return BlocProvider(
      create: (_) => CounterShoppingCart(),
      child: Scaffold(
            key: scaffoldKey,
            appBar: AppBarHome(),
            body: BodyHome(_useCaseConfig),
      ),
    );
  }
}
